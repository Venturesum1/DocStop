import express from "express";
import Token from "../models/TokenModel.js"
import User from "../models/UserModel.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const router = express.Router();

router.post("/signup", async (req, res) => {
    const { name, email, password } = req.body;

    const userExist = await User.findOne({ email });

    if (userExist) return res.status(400).json({ error: "This email ID is already registered." })

    const hashedPass = await bcrypt.hash(password, 10);

    const newUser = new User({ name, email, password: hashedPass });
    try {
        await newUser.save();
    } catch (error) {
        return res.status(500).json({ error: error.message })
    }

    return res.status(200).json({ message: "Registered Successfully" });
})

router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    const userExist = await User.findOne({ email });

    if (!userExist) return res.status(400).json({ error: "Invalid username or password" });

    const passMatch = await bcrypt.compare(password, userExist.password);

    if (!passMatch) return res.status(400).json({ error: "Invalid username or password" });


    const tokenExist = await Token.findOne({ user: userExist._id });
    const accessToken = jwt.sign({ id: userExist._id }, "access");

    if (!tokenExist) {
        const newToken = new Token({
            user: userExist._id,
            token: accessToken
        })
        try {
            await newToken.save();
        } catch (error) {
            return res.status(500).json({ error: error.message })
        }
    }
    else {
        tokenExist.token = accessToken;
        try {
            tokenExist.save();
        } catch (error) {
            return res.status(500).json({ error: error.message })
        }
    }
    res.cookie("jwt", accessToken, {
        expires: new Date(Date.now() + (1000 * 60 * 60 * 24 * 7)),
        httpOnly:true
    });

    return res.status(200).json({ user: userExist });
})

router.post("/verifyToken", async (req, res) => {
    const {id} = req.body
    const userBrowserToken = req.cookies.jwt;

    const token = await Token.findOne({user:id});

    if (!token) return res.status(401).json({error: "Not Authorized"});

    if (token.token != userBrowserToken) return res.status(401).json({error: "Not Authorized"});

    jwt.verify(userBrowserToken, "access", (err, user) => {
        if (err) return res.status(401).json({error: "Not Authorized"});

        return res.status(200).json({message: "Authorized"})
    })

})

router.post("/logout", async (req, res) => {
    const {id} = req.body;
    console.log(id)
    await Token.findOneAndDelete({user: id});
    return res.status(200).json({message: "Logged out successfully"})
})

export default router;