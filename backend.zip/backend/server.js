import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import userRoutes from "./routes/UserRoutes.js";
import cookieParser from "cookie-parser";

const app = express();

app.use(express.json());
app.use(cors({credentials:true,origin:"http://localhost:3000"}));
app.use(cookieParser());
app.use("/user", userRoutes);

const PORT = 5000;
const URL = "mongodb+srv://soumyasis:Soumyasis86616@cluster0.b5o8tvw.mongodb.net/?retryWrites=true&w=majority";

mongoose.connect(URL)
    .then(app.listen(PORT, () => {
        console.log(`Connected to MONGO DB and Server Running on PORT - ${PORT}.`)
    }))
    .catch(error => console.log(error.message))