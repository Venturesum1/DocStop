import mongoose from "mongoose";

const tokenSchema = new mongoose.Schema({
    token: {type: String, required: true},
    user: {type: mongoose.Schema.Types.ObjectId,required:true,ref:'user'}
});
const Token = mongoose.model("token", tokenSchema);
export default Token;