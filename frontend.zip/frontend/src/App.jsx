import MainPage from "./components/MainPage";
import Navbar from "./Navbar/Navbar";
import { Routes, Route } from "react-router-dom";
import PatientList from "./components/PatientList";
import PatientPayment from "./components/PatientPayment";
import "./App.css";
import Login from "./Login/Login";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import About from "./About/About";
import Contact from "./Contact/Contact";

function App() {

  const [auth, setAuth] = useState(false);
  const navigate = useNavigate("/");

  const verifyToken = async () => {
    try {
      const response = await axios.post(`http://localhost:5000/user/verifyToken`, {
        id: localStorage.getItem("userId")
      });
      const data = await response.data;
      if (data) {
        setAuth(true);
      }
    } catch (error) {
      if (error.response.status === 401) {
        setAuth(false);
        navigate("/login")
      }
    }
  }

  axios.defaults.withCredentials = true;
  useEffect(() => {
    verifyToken();
  }, [auth])

  return (
    <>
      <header>
        <Navbar setAuth={setAuth} auth={auth} />
      </header>
      <main>
        <Routes>
          {!auth && <Route path="/login" element={<Login setAuth={setAuth} />} />}
          {auth && <>
            <Route exact path="/" element={<MainPage />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/patientList" element={<PatientList />} />
            <Route path="/patientPayment" element={<PatientPayment />} />
            <Route path="/about" element={<About />} />
          </>}
        </Routes>
      </main>
    </>
  );
}

export default App;
