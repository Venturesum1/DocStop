import { useEffect } from "react"
import Section3Div from "../components/Section3Div"
import "../css/Section3.css";

const Section3 = () => {

    const scrollAnimation = () => {
        const div2 = document.getElementById("div2");
        const div3 = document.getElementById("div3");

        if (window.scrollY > 1000) {
            div2.style = "opacity: 1!important;";
        }

        if (window.scrollY > 1150) {
            div3.style = "opacity: 1!important;";
        }


    }

    useEffect(() => {
        window.addEventListener("scroll", scrollAnimation);
    }, [])

    return (
        <div className="bg-[#e6ffff]">
            <div id="div2" className="my-10 w-[90%] mx-auto grid md:grid-cols-3 gap-4">
                <Section3Div content="Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui." title="Experienced Doctors" />
                <Section3Div content="Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui." title="Professional & Friendly Staff" />
                <Section3Div content="Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui." title="On Call 24/7" />
            </div>
            <div id="div3" className="my-10 w-[90%] mx-auto grid md:grid-cols-3 gap-4">
                <Section3Div content="Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui." title="Same Day Appointments" />
                <Section3Div content="Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui." title="Walk-In's Accepted" />
                <Section3Div content="Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec sed odio dui." title="No Extra Fees" />
            </div>
        </div>
    )
}

export default Section3