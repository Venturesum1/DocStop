import img from "../img/health-icon-10-3.png";
import img2 from "../img/doctor-01.jpg";
import { useEffect } from "react";
import "../css/Section2.css";

const Section2 = () => {
    
    function scrollAnimation() {
        const img1 = document.getElementById("img1");
        const div1 = document.getElementById("div1");
        if (window.scrollY > 450) {
            div1.style = "background-color: #2ea2cc"
            img1.style = "margin-right: 0";
        }
    }

    useEffect(() => {
        window.addEventListener("scroll", scrollAnimation)
    }, [])

    return (
        <div className="my-20 flex flex-col gap-10 items-start md:flex-row md:gap-0 ">
            {/* Content Div */}
            <div className="md:mt-20 flex-1">
                <div className="w-[85%] mx-auto md:w-[70%] md:ml-auto flex flex-col items-start md:items-start gap-4">
                    <img src={img} className="" />
                    <p className="text-[1.7em] md:text-[2.5em] font-extralight">
                        Our Mission Is to Provide a Professional & Honest Approach to Health Care
                    </p>
                    <p className="text-[#999] font-light tracking-wider text-[0.9em] leading-loose font-light">
                        Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum. Nulla vitae elit libero, a pharetra augue. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.
                    </p>
                    <a href="https://www.medindia.net/doctor-appointment/index.asp"> <button className="bg-[#48d14c] text-white py-5 px-7 tracking-wider rounded-full text-[0.8em]">
                        Meet Our Doctors
                    </button></a>
                </div>
            </div>

            {/* Image Div */}
            <div id="div1" className="flex-1 rounded-bl-[50%] rounded-tl-[7%] overflow-hidden overflow-hidden">
                <img id="img1" src={img2} className="h-full rounded-bl-[50%] rounded-tl-[3%] md:rounded-tl-[2%] w-[96%] ml-auto" />
            </div>
        </div>
    )
}

export default Section2