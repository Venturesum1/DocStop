
const Section4 = () => {
    return (
        <div className="my-8 w-[90%] px-12 mx-auto flex flex-col gap-4 items-start md:flex-row justify-between">
            <p className="text-[1.7em] md:text-[2.4em] font-extralight">See If We Are In Your Network</p>
            <a href="https://www.practo.com/"> <button className="bg-[#48d14c] text-white py-5 px-7 tracking-wider rounded-full text-[0.8em]">View Plans</button></a>
        </div>
    )
}

export default Section4