import Section5Card from "../components/Section5Card"
import img1 from "../img/doctor-07.jpg";
import img2 from "../img/health-icon-4-3.png"
import img3 from "../img/doctor-05.jpg";
import img4 from "../img/health-icon-16-3.png"
import img5 from "../img/doctor-23.jpg";
import img6 from "../img/health-icon-2-3.png"
import img7 from "../img/doctor-08.jpg";
import img8 from "../img/health-icon-13-3.png"
import img9 from "../img/doctor-06.jpg";
import img10 from "../img/health-icon-12-3.png"
import img11 from "../img/doctor-04.jpg";
import img12 from "../img/health-icon-9-3.png"
import Section5FeedBack from "../components/Section5FeedBack";
import bgImg from "../img/bgImg.png";


const Section5 = () => {
    return (
        <div id="services" className="mt-20 bg-[#f1f5f7] rounded-tl-[100px] md:rounded-tl-[20%] overflow-hidden pt-32 pb-16">
            <div className="w-[80%] mx-auto flex flex-col items-center justify-center gap-12">
                <h2 className="tracking-wider text-[2.1em] font-extralight">Our Services</h2>
                <p className="text-[0.9em] md:text-[1em] text-center md:w-[70%] tracking-wider leading-loose text-[#666] font-extralight">Aenean lacinia bibendum nulla sed consectetur. Maecenas faucibus mollis interdum. Nulla vitae elit libero, a pharetra augue. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Curabitur blandit tempus</p>

                {/* Cards Div */}
                <div className="w-full">
                    <div className="grid md:grid-cols-3 gap-y-8 md:gap-x-8">
                        <Section5Card img={img1} img2={img2} title="Primary Care" content="Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vestibulum ante ipsum primis. In faucibus orci luctus et ultrices posuere cubilia. Curae donec velit neque porttitor lectus nibh." />
                        <Section5Card img={img3} img2={img4} title="Cardiology" content="Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vestibulum ante ipsum primis. In faucibus orci luctus et ultrices posuere cubilia. Curae donec velit neque porttitor lectus nibh." />
                        <Section5Card img={img5} img2={img6} title="Urgent Care" content="Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vestibulum ante ipsum primis. In faucibus orci luctus et ultrices posuere cubilia. Curae donec velit neque porttitor lectus nibh." />
                        <Section5Card img={img7} img2={img8} title="Pharmaceutical" content="Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vestibulum ante ipsum primis. In faucibus orci luctus et ultrices posuere cubilia. Curae donec velit neque porttitor lectus nibh." />
                        <Section5Card img={img9} img2={img10} title="Newborn Care" content="Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vestibulum ante ipsum primis. In faucibus orci luctus et ultrices posuere cubilia. Curae donec velit neque porttitor lectus nibh." />
                        <Section5Card img={img11} img2={img12} title="Pediatric Care" content="Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vestibulum ante ipsum primis. In faucibus orci luctus et ultrices posuere cubilia. Curae donec velit neque porttitor lectus nibh." />
                    </div>
                </div>
            </div>

            {/* FeedBack Form Div */}
            <div className="mt-32 flex items-stretch gap-2">
                <div className="flex-1">
                    <img src={bgImg} className="w-full h-full" />
                </div>
                <Section5FeedBack />
            </div>
        </div>
    )
}

export default Section5