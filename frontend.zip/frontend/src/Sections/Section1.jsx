import "../css/Section1.css";
import img from "../img/CTA-Image-01.jpg";
import img2 from "../img/health-icon-3-2.png";

const Section1 = () => {
    return (
        <div id="section1" className="relative">
            {/* BG-Image div */}
            <div>
                <img src={img} className="object-fill h-[400px] md:h-auto w-full" />
            </div>
            {/* Overlay Div */}
            <div className="overlay z-0 w-full h-full absolute top-0 left-0">

            </div>

            {/* Content Div */}
            <div className="contentDiv absolute w-full h-full top-0 left-0">
                <div className="flex flex-col items-center gap-4 h-full justify-center mt-auto w-[80%] mx-auto">
                    <img src={img2} className="object-fill" />
                    <h2 className="text-[5vw] text-white text-center font-medium tracking-wide">
                        We Are Committed to Your<br />Health
                    </h2>
                    <p className="text-lg text-white text-center tracking-wider">Our doctors are on call 24/7. Same Day Appointments Available.</p>
                    <a href="#section5">
                        <button className="bg-[#48d14c] text-white rounded-full tracking-wider px-7 py-5 text-[0.8em]">Book an appointment</button>
                    </a>
                </div>
            </div>
        </div>
    )
}

export default Section1