import { useEffect } from "react"
import Section1 from "../Sections/Section1"
import Section2 from "../Sections/Section2"
import Section3 from "../Sections/Section3"
import Section4 from "../Sections/Section4"
import Section5 from "../Sections/Section5"

const MainPage = () => {

    useEffect(() => {
        document.body.style = "background: white"
    }, [])

    return (
        <>
            <section>
                <Section1 />
            </section>
            <section>
                <Section2 />
            </section>
            <section>
                <Section3 />
            </section>
            <section>
                <Section4 />
            </section>
            <section>
                <Section5 />
            </section>
        </>
    )
}

export default MainPage