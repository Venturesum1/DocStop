import DoneIcon from '@mui/icons-material/Done';

const Section3Div = ({ title, content }) => {
    return (
        <div className="mx-auto w-[80%]">
            <div className="flex items-center gap-2">
                <div className="bg-[#c5dfff] rounded-full p-2 px-2.5">
                    <DoneIcon sx={{ color: "blue", fontSize: 18 }} />
                </div>
                <p className='tracking-wider'>{title}</p>
            </div>
            <p className='font-light ml-12 mt-4 leading-loose text-[#999] text-sm'>
                {content}
            </p>
        </div>
    )
}

export default Section3Div