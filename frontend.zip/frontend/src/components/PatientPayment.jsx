import off from "./off.jpg"

const PatientPayment = () => {
    return (
        <div className="flex flex-col">
            <div className="px-8 py-2  bg-[#01cbeb]">
                <h1 className="text-6xl text-white">INVOICE</h1>
            </div>
            <div className="max-h-[430px] overflow-hidden">
                <img src={off} className="w-full h-full" alt="" />
            </div>

            <div className="flex flex-col md:flex-row gap-2 justify-between w-full px-6 py-4">
                <div className="flex w-full md:w-[70%] flex-col md:border-r-[1px] md:pr-6">
                    <div className="flex w-full justify-between py-2 border-b-[2px] px-2">
                        <p className="text-[#01cbeb] flex-1 font-bold">Description</p>
                        <p className="text-[#01cbeb] text-right flex-1 font-bold">Rate</p>
                        <p className="text-[#01cbeb] flex-1 text-right font-bold">Qty</p>
                        <p className="text-[#01cbeb] flex-1 text-right font-bold">Line Total</p>
                    </div>

                    <div className="flex w-full justify-between py-2 border-b-[2px] px-2">
                        <p className="flex-1">Your Item Name</p>
                        <p className="flex-1 text-right">$200.00</p>
                        <p className="flex-1 text-right">1</p>
                        <p className="flex-1 text-right">$200.00</p>
                    </div>

                    <div className="pt-12 w-full flex flex-col gap-4">
                        <div className="ml-auto w-[75%] md:w-[50%] justify-between flex">
                            <p className="text-right flex-1">Subtotal</p>
                            <p className="text-right flex-1">200.00</p>
                        </div>
                        <div className="ml-auto w-[75%] md:w-[50%] justify-between flex border-b-dotted border-b-[2px] pb-2" style={{ borderStyle: "dotted" }}>
                            <p className="text-right text-right flex-1">Tax</p>
                            <p className="flex-1 text-right">0.00</p>
                        </div>
                    </div>

                    <div className="flex flex-col gap-2 py-2">
                        <div className="ml-auto w-[75%] md:w-[50%] justify-between flex">
                            <p className="text-right flex-1">Total</p>
                            <p className="text-right flex-1">200.00</p>
                        </div>
                        <div className="ml-auto pb-2 w-[75%] md:w-[50%] border-b-[2px] justify-between flex" style={{ borderStyle: "dotted" }}>
                            <p className="text-right flex-1">Amount Paid</p>
                            <p className="text-right flex-1">0.00</p>
                        </div>

                        <div className="ml-auto pb-2 w-[75%] md:w-[50%] border-b-[2px] justify-between flex" style={{ borderStyle: "dotted" }}>
                            <p className="text-[#01cbeb] text-right flex-1 font-bold">Amount Due (USD)</p>
                            <p className="text-right flex-1">$200.00</p>
                        </div>
                    </div>
                </div>
                <div className="flex w-full md:w-[30%] gap-1 flex-col text-right p-2">
                    <p className="text-lg text-[#01cbeb] font-bold">Amount Due (USD)</p>
                    <p className="text-2xl md:text-5xl">$200.00</p>

                    <div className="mt-4">
                        <p className="text-[#01cbeb] font-bold">Billed To</p>
                        <p>Client Name</p>
                        <p>Street Address</p>
                        <p>City, State</p>
                        <p>Zip Code</p>
                    </div>

                    <div className="mt-4">
                        <p className="text-[#01cbeb] font-bold">Invoice No</p>
                        <p>000001</p>
                    </div>

                    <div className="mt-4">
                        <p className="text-[#01cbeb] font-bold">Date of Time</p>
                    </div>

                    <div className="mt-4">
                        <p className="text-[#01cbeb] font-bold">Due Date</p>
                        <p>Invalid Date</p>
                    </div>
                </div>
            </div>
            <div className="text-center px-8 py-2 bg-[#01cbeb]">
                <p className="text-white text-4xl">Medical Invoice Template</p>
            </div>
        </div>
    )
}

export default PatientPayment