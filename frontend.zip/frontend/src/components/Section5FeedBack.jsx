import img1 from "../img/doctor-02.jpg";
import "../css/Section5.css";
import img2 from "../img/health-icon-3-2.png";

const Section5FeedBack = () => {
    return (
        <div id="section5" className="relative rounded-bl-[3%] rounded-tl-[5%] overflow-hidden w-[95%] ml-auto">
            <div>
                <img src={img1} className="w-full h-[800px] md:h-[900px]" />
            </div>
            <div className="z-0 overlay absolute top-0 left-0 w-full h-full"></div>
            

            {/* Form Div */}
            <div className="px-4 md:px-0 flex flex-col items-center justify-center absolute top-0 left-0 w-full h-full gap-4">
                <img src={img2} />
                <p className="text-white text-[1.8em] md:text-[3.5em] text-center font-[300]">Your Health Starts Here</p>
                <p className="text-white text-[1.2em] md:text-[1.3em] text-center tracking-wider font-[300]">Flexible appointments and urgent care.</p>
                <p className="font-bold text-[1.1em] md:text-[1.3em] text-white tracking-wider">Or call — 344 532 2352</p>
                <form className="md:w-[60%] flex flex-col w-full mx-auto">
                    <div className="justify-between flex flex-col md:flex-row items-stretch md:items-center gap-4">
                        <input className="flex-1 p-4 text-sm font-[300] px-4 rounded-md focus:outline-none" type="text" placeholder="Your Full Name" />
                        <input className="flex-1 p-4 text-sm font-[300] px-4 rounded-md focus:outline-none" type="tel" placeholder="Phone Number" />
                    </div>

                    <div className="mt-4 justify-between flex flex-col md:flex-row items-stretch md:items-center gap-4">
                        <input className="flex-1 p-4 text-sm font-[300] px-4 rounded-md focus:outline-none" type="email" placeholder="Email Address" />
                        <select className="flex-1 p-4 text-sm font-[300] rounded-md focus:outline-none text-[grey]">
                            <option>Provide a name</option>
                            <option>Provide a name</option>
                            <option>Provide a name</option>
                            <option>Provide a name</option>
                        </select>
                    </div>
                    <div className="mt-4">
                        <textarea className="w-full p-4 text-sm font-[300] min-h-[130px] max-h-[130px] rounded-sm focus:outline-none" placeholder="Reason for Visiting" rows="5"></textarea>
                    </div>
                    <button className="ml-auto mt-2 text-white text-[0.8em] tracking-wider p-4 rounded-full bg-[#48d14c]">Submit Appointment Request</button>
                </form>
            </div>
        </div>
    )
}

export default Section5FeedBack