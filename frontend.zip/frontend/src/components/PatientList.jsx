import { useEffect } from "react"
import patientPic from "../img/pPic.png";
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

const PatientList = () => {

    useEffect(() => {
        document.body.style = "background: #f2f5f9;"
    }, [])

    return (
        <div className="flex flex-col gap-4 px-8 py-4">

            <div>
                <div className="flex items-center gap-2">
                    <p className="text-[#0d53fc] tracking-wider">Patient List</p>
                    <p>
                        <KeyboardArrowRightIcon sx={{ color: "grey", fontSize: "22px" }} />
                    </p>
                    <p className="text-[grey]">Diane Cooper</p>
                </div>
            </div>

            <div className="flex md:flex-row flex-col items-stretch gap-4 justify-between">
                <div className="flex p-8 flex-col items-center gap-5 md:gap-3 rounded-md bg-white">
                    <img className="w-1/3 md:w-2/3" src={patientPic} alt="" />
                    <div className="flex flex-col items-center">
                        <h2 className="font-bold text-lg tracking-wider">John Doe</h2>
                        <p className="text-[grey] text-[14px] tracking-wider">JohnDoe@example.com</p>
                    </div>

                    <div className="flex w-full">
                        <div className="flex-1 flex flex-col items-center border-r-[1px]">
                            <p className="text-lg font-bold">15</p>
                            <p className="text-sm text-[grey]">Post</p>
                        </div>
                        <div className="flex-1 flex flex-col items-center">
                            <p className="text-lg font-bold">2</p>
                            <p className="text-sm text-[grey]">Upcoming</p>
                        </div>
                    </div>

                    <a href="https://globfone.com/send-text/"> <button className="font-bold tracking-wider mt-2 text-sm">Send Message</button></a>
                </div>

                <div className="bg-white p-8 rounded-md flex-1">
                    <div className="grid h-[100%] gap-8 md:gap-0 grid-cols-2 md:grid-cols-3">
                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Gender</p>
                            <p className="tracking-wider font-light">Male</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Birthday</p>
                            <p className="tracking-wider font-light">Feb 24th, 1997</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Phone Number</p>
                            <p className="tracking-wider font-light">(239)555-0108</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Street Address</p>
                            <p className="tracking-wider font-light">Jl, San Fransico, 21</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">City</p>
                            <p className="tracking-wider font-light">Cilacop</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">ZIP Code</p>
                            <p className="tracking-wider font-light">655849</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Member Status</p>
                            <p className="tracking-wider font-light">Active Member</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Phone Number</p>
                            <p className="tracking-wider font-light">(239) 555-0108</p>
                        </div>

                        <div className="flex flex-col gap-1">
                            <p className="font-bold text-[grey] tracking-wider">Registered Date</p>
                            <p className="tracking-wider font-light">Feb 24th, 1997</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="px-2 md:px-4 py-6 bg-white flex flex-col gap-6 items-stretch md:items-start">
                <div className="flex justify-between bg-[#f2f5f9] p-1 rounded-md md:gap-0 gap-2">
                    <button className="tracking-wider font-bold text-[#0d53fc] text-sm p-2 md:px-4 bg-white rounded-sm">Upcoming Appointments</button>
                    <button className="tracking-wider font-bold text-[grey] text-sm p-2 md:px-4">Past Appointments</button>
                    <button className="tracking-wider font-bold text-[grey] text-sm p-2 md:px-4">Medical Records</button>
                </div>

                <div className="bg-[#f2f5f9] flex flex-col gap-4 p-4 w-full rounded-md">
                    <div className="flex items-center justify-between">
                        <h3 className="tracking-wider md:text-md text-sm">Root Canal Treatment</h3>
                        <button className="p-2 px-4 text-sm bg-white text-[grey] font-bold tracking-wider flex gap-1 items-center">
                            <KeyboardArrowUpIcon />
                            Show Previous Treatment
                        </button>
                    </div>

                    <div className="p-4 flex md:flex-row flex-col gap-4 bg-white rounded-md">
                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-xl">26 Nov '19</p>
                            <p className="text-[grey] text-[12px]">9:00-10:00</p>
                        </div>
                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-[12px] text-[grey]">Treatment</p>
                            <p className="font-bold">Open Access</p>
                        </div>

                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-[12px] text-[grey]">Dentist</p>
                            <p>Drg. Adam H.</p>
                        </div>

                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-[12px] text-[grey]">Nurse</p>
                            <p>Jessicamila</p>
                        </div>
                    </div>

                    <div className="p-4 flex md:flex-row flex-col gap-4 bg-white rounded-md">
                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-xl">12 Dec '19</p>
                            <p className="text-[grey] text-[12px]">9:00-10:00</p>
                        </div>
                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-[12px] text-[grey]">Treatment</p>
                            <p className="font-bold">Root Canal Gap</p>
                        </div>

                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-[12px] text-[grey]">Dentist</p>
                            <p>Drg. Adam H.</p>
                        </div>

                        <div className="flex-col flex gap-1 flex-1 border-b-[1px] py-2 md:border-b-0 md:border-r-[1px]">
                            <p className="tracking-wider text-[12px] text-[grey]">Nurse</p>
                            <p>Jessicamila</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default PatientList