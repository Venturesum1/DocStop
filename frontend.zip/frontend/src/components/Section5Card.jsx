
const Section5Card = ({ img, img2, title, content }) => {
    return (
        <div className="bg-white mx-auto overflow-hidden rounded-[20px] flex flex-col items-center pb-8">
            <img src={img} />
            <img src={img2} className="mt-12" />
            <p className="text-lg tracking-wider mt-8">{title}</p>
            <p className="px-5 text-center tracking-wider mt-2 text-sm leading-[2em]">{content}</p>
            <a href="https://www.who.int/teams/integrated-health-services/clinical-services-and-systems/primary-care"> <button className="bg-[#0000000d] tracking-wider mt-2 text-[#2f8cff] text-sm p-1 px-4 rounded-full">Learn More</button></a>
        </div>
    )
}

export default Section5Card