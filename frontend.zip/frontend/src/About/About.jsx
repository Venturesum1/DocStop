import img3 from "./3.jpg"
import img4 from "./4.jpg"
import img2 from "./2.JPG"

// import EmailIcon from '@mui/icons-material/AlternateEmail';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import img1 from "./1.jpg"
const About = () => {
    return (
        <div className="m-4 p-4 bg-white shadow-sm h-full flex flex-col gap-8">
            <h1 className="text-center tracking-wider text-3xl text-[#232157]">MEET OUR TEAM</h1>

            <div className="flex flex-col md:flex-row gap-4 justify-between items-center md:items-stretch">
                <div className="w-[60%] h-[400px] rounded-sm overflow-hidden md:max-h-[400px] md:w-[30%]">
                    <img src={img1} className="w-full md:w-[100%] h-full" alt="" />
                </div>
                <div className="md:w-[65%] flex flex-col gap-4 justify-center items-center md:items-start">
                    <p className="text-2xl text-[#232157] font-bold tracking-wider">Soumyasis(Developer :))</p>
                    <p className="text-center md:text-start">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque autem quisquam error optio ex? Quidem vero atque facilis in similique?</p>
                    <div className='flex flex-col gap-1'>
                        <div className="flex items-center">
                            <PhoneIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- 9876543212</p>
                        </div>
                        <div className="flex items-center">
                            <EmailIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- xyz@gmail.com</p>
                        </div>
                    </div>

                </div>
            </div>
            <hr />
            <div className="flex flex-col justify-between md:flex-row gap-4 items-center md:items-stretch">
                <div className="md:w-[65%] flex flex-col gap-4 justify-center items-center md:items-start order-1 md:order-[-1]">
                    <p className="text-2xl text-[#232157] font-bold tracking-wider">Sherya(design and creative handling :))</p>
                    <p className="text-center md:text-start">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque autem quisquam error optio ex? Quidem vero atque facilis in similique?</p>
                    <div className='flex flex-col gap-1'>
                        <div className="flex items-center">
                            <PhoneIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- 9876543212</p>
                        </div>
                        <div className="flex items-center">
                            <EmailIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- xyz@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div className="w-[60%] h-[400px] rounded-sm overflow-hidden md:max-h-[400px] md:w-[30%]">
                    <img src={img2} className="w-full md:ml-auto md:w-[100%] h-full" alt="" />
                </div>
            </div>
            <hr />
            <div className="flex flex-col md:flex-row gap-4 justify-between items-center md:items-stretch">
                <div className="w-[60%] h-[400px] rounded-sm overflow-hidden md:max-h-[400px] md:w-[30%]">
                    <img src={img4} className="w-full md:w-[100%] h-full" alt="" />
                </div>
                <div className="md:w-[65%] flex flex-col gap-4 justify-center items-center md:items-start">
                    <p className="text-2xl text-[#232157] font-bold tracking-wider">Siddhant(Content writing and creative handling :))</p>
                    <p className="text-center md:text-start">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque autem quisquam error optio ex? Quidem vero atque facilis in similique?</p>
                    <div className='flex flex-col gap-1'>
                        <div className="flex items-center">
                            <PhoneIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- 9876543212</p>
                        </div>
                        <div className="flex items-center">
                            <EmailIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- xyz@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>
            <hr />
            <div className="flex flex-col justify-between md:flex-row gap-4 items-center md:items-stretch">
                <div className="md:w-[65%] flex flex-col gap-4 justify-center items-center md:items-start order-1 md:order-[-1]">
                    <p className="text-2xl text-[#232157] font-bold tracking-wider">Siddharth (web designing and development :))-</p>
                    <p className="text-center md:text-start">Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque autem quisquam error optio ex? Quidem vero atque facilis in similique?</p>
                    <div className='flex flex-col gap-1'>
                        <div className="flex items-center">
                            <PhoneIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- 9876543212</p>
                        </div>
                        <div className="flex items-center">
                            <EmailIcon sx={{ fontSize: "16px", color: 'black' }} />
                            <p className='text-[14px] tracking-wider text-[black]'>&nbsp;- xyz@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div className="w-[60%] h-[400px] rounded-sm overflow-hidden md:max-h-[400px] md:w-[30%]">
                    <img src={img3} className="w-full md:w-[100%] md:ml-auto h-full" alt="" />
                </div>
            </div>
        </div>
    )
}

export default About