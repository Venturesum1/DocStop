import ManageHistoryIcon from '@mui/icons-material/ManageHistory';
import "./Contact.css";

const Contact = () => {
    return (
        <div className="">
            <div id="mycontact" className="flex items-center justify-center relative min-h-[600px] md:min-h-[600px] w-full z-0">
                <div className="absolute top-0 left-0 w-full h-full bg-black z-0 opacity-[0.4]"></div>
                <div className="w-[90%] md:w-[70%] h-full gap-4 z-20 flex items-end flex-col" id="btnDiv">
                    <button className="p-2 bg-[#00b3ff] text-white rounded-full font-bold px-4 tracking-wider text-lg md:text-xl">Welcome to our Hekim</button>
                    <button id="mybtn" className="p-2 text-[#00b3ff] rounded-full font-bold px-4 tracking-wider text-2xl md:text-3xl">Best Health Care Solution</button>
                    <button className="bg-[transparent] px-4 text-white border-[1px] border-white p-2 rounded-md tracking-wider text-sm">Get A Quote</button>
                </div>
            </div>
            <div className="w-full md:absolute md:mt-[-20px] z-40 flex justify-center">
                <div className="grid grid-cols-2 gap-4 mt-8 md:gap-0 md:mt-0 md:grid-cols-4 w-[95%] md:w-[80%]">
                    <div className="bg-[#00b3ff] rounded-tr-[20px] flex flex-col gap-4 p-6 rounded-bl-[20px] items-start">
                        <p className="tracking-wider font-[600] text-white">Appointment.</p>
                        <p className="text-white text-justify leading-[1.7em] tracking-wider text-[13px]">Which problem you faced on your health ?call or mail us and make an appointment with our expert who can solved your problem.</p>
                        <a href="https://www.doctor24x7.in/"> <button className="bg-white p-1 px-4 py-2 text-[10px]">Apointment Now</button></a>
                    </div>
                    <div className="bg-[#337ab7] rounded-tr-[20px] flex flex-col gap-4 p-6 rounded-bl-[20px] items-start">
                        <p className="tracking-wider text-white font-[600]">Doctor's Schedule.</p>
                        <p className="text-white text-justify leading-[1.7em] tracking-wider text-[13px]">
                            Take a look on our clinic Doctor's timetable and make an appointment with our expert which department or service.
                        </p>
                        <a href="https://hospital.iitd.ac.in/all/doctors/schedule"> <button className="mt-auto bg-white p-1 px-4 py-2 text-[10px]">View Timetable</button></a>
                    </div>
                    <div className="bg-[#145892] rounded-tr-[20px] flex flex-col gap-4 p-6 rounded-bl-[20px] items-start">
                        <p className="tracking-wider text-white font-[600]">Emergency Cases.</p>
                        <div className="flex items-center">
                            <ManageHistoryIcon sx={{ color: "white" }} />
                            <p className="text-white text-sm">+99-55-66-88-526</p>
                        </div>
                        <p className="text-white text-justify leading-[1.7em] tracking-wider text-[13px]">
                            You can call us for emargency & make an appointment out of clinic.
                        </p>
                        <a href="https://www.doctor24x7.in/"> <button className="bg-white p-1 mt-auto px-4 py-2 text-[10px]">Appointment Now</button></a>
                    </div>
                    <div className="bg-[#004274] rounded-tr-[20px] flex flex-col gap-4 p-6 rounded-bl-[20px]">
                        <p className="tracking-wider text-white font-[600]">Opening Hour</p>
                        <div className="flex flex-col gap-2">
                            <div className="flex items-center justify-between w-full border-b-[1px] py-1">
                                <p className="font-bold text-[12px] text-white">Mon-Fri</p>
                                <p className="text-white text-[11px]">8:00-20:30</p>
                            </div>
                            <div className="flex items-center justify-between w-full border-b-[1px] py-1">
                                <p className="font-bold text-[12px] text-white">Saturday</p>
                                <p className="text-white text-[11px]">8:00-18:00</p>
                            </div>
                            <div className="flex items-center justify-between w-full border-b-[1px] py-1">
                                <p className="font-bold text-[12px] text-white">Sunday</p>
                                <p className="text-white text-[11px]">9:00-14:30</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Contact