import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = ({setAuth}) => {
  
  axios.defaults.withCredentials=true;
  const navigate = useNavigate();
  const [login, setLogin] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const URL = "http://localhost:5000"

  const formSubmit = async (e) => {
    e.preventDefault();

    if (!login) {
      if (!name.trim()) {setError("Name cannot be empty");
      return false;
    }
      else if (name.length <3) setError("Name is to small");
      else if (!email.trim()){  setError("Email is required");
      return false;
  }
      else if (!password) setError("Password cannot be empty");
      else if (password.length<8) setError("Password is too short");
      else setError("")

      try {
        const response = await axios.post(`${URL}/user/signup`, {
          name,email,password
        });
        const data = await response.data;
        console.log(data)
        setLogin(true);
        setName('');
        setPassword('');
        setEmail('');
      } catch (error) {
        setError(error.response.data.error)
      }
    }
    else {
      if (!email) setError("Email is required");
      else if (!password) setError("Password cannot be empty");
      else setError("");

      try {
        const response = await axios.post(`${URL}/user/login`,{email, password});
        const data = await response.data;
        console.log(data)
        localStorage.setItem("userId", data.user._id);
        setAuth(true);
        navigate("/");
      } catch (error) {
        console.log(error)
        setError(error.response.data.error);
      }
    }
  }

  return (
    <div className="w-[80%] md:w-[40%] mx-auto bg-white flex flex-col items-stretch gap-4 p-8 rounded-md shadow-lg my-8">
            <h2 className="text-xl font-bold tracking-wider text-center">{login ? "Login" : "Sign-Up"}</h2>
            <form onSubmit={formSubmit} className="flex flex-col gap-6">
                <div className="flex flex-col gap-6">
                    {!login && <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" type="text" className="w-full border-b-[1px] focus:outline-none tracking-wider py-[1px]" />}
                    <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email" className="w-full border-b-[1px] focus:outline-none tracking-wider py-[1px]" />
                    <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password" className="w-full border-b-[1px] focus:outline-none tracking-wider py-[1px]" />
                </div>
                <p className="text-[red] tracking-wider text-sm text-center">{error}</p>
                <div className="flex flex-col mt-2 gap-4">
                    <button className="bg-[orange] text-white tracking-wider py-1 rounded-sm">{login ? 'Login' : 'Sign-up'}</button>
                    {login && <p onClick={() => setLogin(false)} className="cursor-pointer text-[blue] text-center tracking-wider text-sm">Don't have an account?</p>}
                    {!login && <p onClick={() => setLogin(true)} className="cursor-pointer text-[blue] text-center tracking-wider text-sm">Already have an account?</p>}
                </div>
            </form>
        </div>
  )
}

export default Login