import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import logo from "./siteLogo.png";

const Navbar = ({ auth, setAuth }) => {

    const navigate = useNavigate();

    const logout = async () => {
        try {
            const response = await axios.post("http://localhost:5000/user/logout", {
                id: localStorage.getItem("userId")
            })
            const data = await response.data;
            console.log(data)
            if (data) setAuth(false);
        } catch (error) {
            console.log(error)
        }
    }

    return (
        <nav className="shadow-md bg-white py-6 px-8 flex items-center justify-between">
            <div className="flex items-center gap-2">
                <img src={logo} alt="Docstop Logo" className='w-[180px]' />
            </div>
            <ul className="flex items-center gap-5">
                {auth && <>
                    <li onClick={() => navigate("/")} className="text-sm cursor-pointer">Home</li>
                    <li className="text-sm cursor-pointer"><a href="#services">Services</a></li>
                    <li onClick={() => navigate("/about")} className="text-sm cursor-pointer">About</li>
                    <li onClick={() => navigate("/contact")} className="text-sm cursor-pointer">Contact</li>
                    <li onClick={() => navigate("/patientList")} className="text-sm cursor-pointer">Admin</li>
                    <li onClick={() => navigate("/patientPayment")} className="text-sm cursor-pointer">Payment</li>
                    <li onClick={() => logout()} className="text-sm cursor-pointer">Logout</li>
                    {/* <li className="text-sm cursor-pointer"><ShoppingCartIcon sx={{ fontSize: 16 }} /></li> */}
                </>}
            </ul>
        </nav>
    )
}

export default Navbar